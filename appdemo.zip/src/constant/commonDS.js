export const status = {
    REQUEST:0,
    SUCCESS:1,
    ERROR:2
}